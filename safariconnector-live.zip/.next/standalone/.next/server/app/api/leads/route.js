var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/leads/route.js")
R.c("server/chunks/[root-of-the-server]__bc1a471e._.js")
R.c("server/chunks/_11f70134._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_42103433._.js")
R.c("server/chunks/_next-internal_server_app_api_leads_route_actions_8059d9e6.js")
R.m(74851)
module.exports=R.m(74851).exports
