var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/itinerary/generate/route.js")
R.c("server/chunks/[root-of-the-server]__8e283544._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_d4db1881.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_itinerary_generate_route_actions_5bae9826.js")
R.m(12432)
module.exports=R.m(12432).exports
