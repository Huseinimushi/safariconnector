var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/trips/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__6ecc5a3d._.js")
R.c("server/chunks/_11f70134._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_42103433._.js")
R.c("server/chunks/_next-internal_server_app_api_trips_[id]_route_actions_cff0df77.js")
R.m(7241)
module.exports=R.m(7241).exports
