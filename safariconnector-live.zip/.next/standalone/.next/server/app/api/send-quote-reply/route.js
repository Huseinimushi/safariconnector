var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-quote-reply/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__9bbd7810._.js")
R.c("server/chunks/_next-internal_server_app_api_send-quote-reply_route_actions_3bf29088.js")
R.m(66157)
module.exports=R.m(66157).exports
