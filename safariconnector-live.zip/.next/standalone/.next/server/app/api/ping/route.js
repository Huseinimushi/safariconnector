var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ping/route.js")
R.c("server/chunks/[root-of-the-server]__7ba3ec8d._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_ping_route_actions_8c5eb44e.js")
R.m(86686)
module.exports=R.m(86686).exports
