var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/quotes/by-operator/route.js")
R.c("server/chunks/[root-of-the-server]__183956c4._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_42103433._.js")
R.c("server/chunks/_next-internal_server_app_api_quotes_by-operator_route_actions_3ec3117e.js")
R.m(92927)
module.exports=R.m(92927).exports
