var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/quotes/accept/route.js")
R.c("server/chunks/[root-of-the-server]__0828f4ca._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_42103433._.js")
R.c("server/chunks/_next-internal_server_app_api_quotes_accept_route_actions_e12b8a04.js")
R.m(84644)
module.exports=R.m(84644).exports
